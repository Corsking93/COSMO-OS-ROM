PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/lineage_cosmos_kiev.mk

COMMON_LUNCH_CHOICES := \
    lineage_cosmos_kiev-userdebug
