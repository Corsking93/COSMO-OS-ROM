PRODUCT_DEVICE := kiev
PRODUCT_NAME := cosmos_kiev
PRODUCT_BRAND := COSMOS
PRODUCT_MODEL := COSMOS Moto Ace
PRODUCT_MANUFACTURER := Motorola

PRODUCT_PACKAGE_OVERLAYS += \
    device/motorola/kiev/overlay

PRODUCT_COPY_FILES += \
    device/motorola/kiev/prebuilt/bootanimation.zip:system/media/bootanimation.zip \
    device/motorola/kiev/init/init.cosmos.rc:$(TARGET_COPY_OUT_VENDOR)/etc/init/init.cosmos.rc

PRODUCT_PACKAGES += \
    CosmosLauncher

PRODUCT_PROPERTY_OVERRIDES += \
    ro.cosmos.version=1.0 \
    ro.cosmos.device=kiev \
    ro.launcher.default=CosmosLauncher
