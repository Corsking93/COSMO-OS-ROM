# COSMOS Kiev Scaffold

This tree is a scaffold only.

Missing for real bring-up:
- real proprietary blobs
- real fstab entries
- kernel validation
- recovery specifics
- SELinux refinement
- verified partition sizes
- hardware bring-up
