#!/usr/bin/env bash
set -e

SRC="${1:-adb}"
VENDOR="motorola"
DEVICE="kiev"
OUT="vendor/$VENDOR/$DEVICE/proprietary"

mkdir -p "$OUT"

while read -r FILE; do
    [[ -z "$FILE" || "$FILE" =~ ^# ]] && continue
    DEST="$OUT/$FILE"
    mkdir -p "$(dirname "$DEST")"

    if [ "$SRC" = "adb" ]; then
        adb pull "/$FILE" "$DEST" || true
    else
        cp -av "$SRC/$FILE" "$DEST" || true
    fi
done < "vendor/$VENDOR/$DEVICE/proprietary-files.txt"

echo "Extraction pass complete."
