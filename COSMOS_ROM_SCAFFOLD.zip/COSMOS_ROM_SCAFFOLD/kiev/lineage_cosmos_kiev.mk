$(call inherit-product, device/motorola/kiev/cosmos_kiev.mk)

PRODUCT_NAME := lineage_cosmos_kiev
PRODUCT_DEVICE := kiev
PRODUCT_BRAND := COSMOS
PRODUCT_MODEL := COSMOS Moto Ace
PRODUCT_MANUFACTURER := Motorola

PRODUCT_GMS_CLIENTID_BASE := android-motorola
