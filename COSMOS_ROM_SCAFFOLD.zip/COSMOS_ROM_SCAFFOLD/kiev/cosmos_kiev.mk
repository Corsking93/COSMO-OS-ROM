$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/full_base.mk)
$(call inherit-product, device/motorola/kiev/device.mk)

PRODUCT_NAME := cosmos_kiev
PRODUCT_DEVICE := kiev
PRODUCT_BRAND := COSMOS
PRODUCT_MODEL := COSMOS Moto Ace
PRODUCT_MANUFACTURER := Motorola
