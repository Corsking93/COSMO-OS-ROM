PRODUCT_COPY_FILES += \
    vendor/motorola/kiev/proprietary/vendor/etc/placeholder.conf:$(TARGET_COPY_OUT_VENDOR)/etc/placeholder.conf
