package com.cosmos.launcher;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = 40;
        layout.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("COSMOS OS");
        title.setTextSize(28f);

        TextView subtitle = new TextView(this);
        subtitle.setText("System launcher scaffold online");

        Button settings = new Button(this);
        settings.setText("Open Settings");
        settings.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_SETTINGS))
        );

        layout.addView(title);
        layout.addView(subtitle);
        layout.addView(settings);

        setContentView(layout);
    }
}
