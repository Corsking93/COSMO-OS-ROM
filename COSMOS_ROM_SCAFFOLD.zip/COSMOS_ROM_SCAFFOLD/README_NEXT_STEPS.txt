COSMOS ROM Scaffold Backup

Contents:
- device/motorola/kiev
- vendor/motorola/kiev
- CosmosLauncher_ROM_App

Next steps on PC/cloud:
1. Sync full AOSP or Lineage tree on Linux workstation
2. Copy device/, vendor/, and launcher app into source tree
3. Replace placeholder vendor blobs with real extracted blobs
4. Replace placeholder fstab with device-accurate fstab
5. Validate kernel source/config
6. Fix SELinux policy incrementally
7. Build launcher module first
8. Attempt product lunch target
9. Attempt boot image / full ROM build
